import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  balance: integer("balance").notNull().default(0),
  wins: integer("wins").notNull().default(0),
  totalEarnings: integer("total_earnings").notNull().default(0),
});

export const gameRooms = pgTable("game_rooms", {
  id: serial("id").primaryKey(),
  roomCode: text("room_code").notNull().unique(),
  dealerName: text("dealer_name").notNull().default("Lady Victoria"),
  maxPlayers: integer("max_players").notNull().default(6),
  currentPlayers: integer("current_players").notNull().default(0),
  gameStatus: text("game_status").notNull().default("waiting"), // waiting, playing, finished
  currentRound: integer("current_round").notNull().default(0),
  maxRounds: integer("max_rounds").notNull().default(5),
  currentPlayerIndex: integer("current_player_index").notNull().default(0),
  pot: jsonb("pot").notNull().default([]), // array of bars
  deck: jsonb("deck").notNull().default([]), // remaining cards
  createdAt: timestamp("created_at").defaultNow(),
});

export const gamePlayers = pgTable("game_players", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").notNull(),
  playerId: integer("player_id").notNull(),
  playerName: text("player_name").notNull(),
  position: integer("position").notNull(), // 0-5 around table
  bars: jsonb("bars").notNull().default([]), // array of gold/silver bars
  cards: jsonb("cards").notNull().default([]), // player's cards
  currentCard: text("current_card"), // card played this round
  isActive: boolean("is_active").notNull().default(true),
  isReady: boolean("is_ready").notNull().default(false),
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").notNull(),
  playerId: integer("player_id"),
  playerName: text("player_name").notNull(),
  message: text("message").notNull(),
  messageType: text("message_type").notNull().default("chat"), // chat, emote, system
  timestamp: timestamp("timestamp").defaultNow(),
});

// Zod schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertGameRoomSchema = createInsertSchema(gameRooms).pick({
  roomCode: true,
  dealerName: true,
  maxPlayers: true,
  maxRounds: true,
});

export const insertGamePlayerSchema = createInsertSchema(gamePlayers).pick({
  roomId: true,
  playerId: true,
  playerName: true,
  position: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  roomId: true,
  playerId: true,
  playerName: true,
  message: true,
  messageType: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type GameRoom = typeof gameRooms.$inferSelect;
export type InsertGameRoom = z.infer<typeof insertGameRoomSchema>;

export type GamePlayer = typeof gamePlayers.$inferSelect;
export type InsertGamePlayer = z.infer<typeof insertGamePlayerSchema>;

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

// Game-specific types
export type Card = {
  suit: "hearts" | "diamonds" | "clubs" | "spades";
  rank: "A" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10" | "J" | "Q" | "K";
  value: number;
};

export type Bar = {
  type: "gold" | "silver";
  value: number;
};

export type GameState = {
  room: GameRoom;
  players: GamePlayer[];
  messages: ChatMessage[];
  isPlayerTurn: boolean;
  timeLeft: number;
};
