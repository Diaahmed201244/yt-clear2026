import { WebSocketServer, WebSocket } from "ws";
import type { Server } from "http";
import { storage } from "../storage";
import { gameService } from "./gameService";

interface ClientConnection {
  ws: WebSocket;
  userId?: number;
  roomId?: number;
  playerName?: string;
}

export class WebSocketService {
  private wss: WebSocketServer;
  private clients: Map<WebSocket, ClientConnection> = new Map();
  private roomClients: Map<number, Set<WebSocket>> = new Map();

  constructor(server: Server) {
    this.wss = new WebSocketServer({ server, path: '/ws' });
    this.setupWebSocketServer();
  }

  private setupWebSocketServer() {
    this.wss.on('connection', (ws: WebSocket) => {
      console.log('New WebSocket connection');
      
      const clientConnection: ClientConnection = { ws };
      this.clients.set(ws, clientConnection);

      ws.on('message', async (data: Buffer) => {
        try {
          const message = JSON.parse(data.toString());
          await this.handleMessage(ws, message);
        } catch (error) {
          console.error('Error handling WebSocket message:', error);
          this.sendError(ws, 'Invalid message format');
        }
      });

      ws.on('close', () => {
        this.handleDisconnection(ws);
      });

      ws.on('error', (error) => {
        console.error('WebSocket error:', error);
        this.handleDisconnection(ws);
      });
    });
  }

  private async handleMessage(ws: WebSocket, message: any) {
    const client = this.clients.get(ws);
    if (!client) return;

    switch (message.type) {
      case 'join_room':
        await this.handleJoinRoom(ws, message.data);
        break;
      
      case 'play_card':
        await this.handlePlayCard(ws, message.data);
        break;
      
      case 'exchange_money':
        await this.handleExchangeMoney(ws, message.data);
        break;
      
      case 'chat_message':
        await this.handleChatMessage(ws, message.data);
        break;
      
      case 'start_game':
        await this.handleStartGame(ws);
        break;

      case 'ready_up':
        await this.handleReadyUp(ws);
        break;

      default:
        this.sendError(ws, 'Unknown message type');
    }
  }

  private async handleJoinRoom(ws: WebSocket, data: { roomCode: string; playerId: number; playerName: string }) {
    try {
      const room = await storage.getGameRoomByCode(data.roomCode);
      if (!room) {
        this.sendError(ws, 'Room not found');
        return;
      }

      if (room.currentPlayers >= room.maxPlayers) {
        this.sendError(ws, 'Room is full');
        return;
      }

      // Add player to room
      const players = await storage.getPlayersInRoom(room.id);
      const position = players.length;
      
      await storage.addPlayerToRoom({
        roomId: room.id,
        playerId: data.playerId,
        playerName: data.playerName,
        position
      });

      // Update client connection
      const client = this.clients.get(ws)!;
      client.userId = data.playerId;
      client.roomId = room.id;
      client.playerName = data.playerName;

      // Add to room clients
      if (!this.roomClients.has(room.id)) {
        this.roomClients.set(room.id, new Set());
      }
      this.roomClients.get(room.id)!.add(ws);

      // Send initial game state
      await this.sendGameState(room.id);
      
      // Add system message
      await storage.addChatMessage({
        roomId: room.id,
        playerId: null,
        playerName: "System",
        message: `${data.playerName} joined the table`,
        messageType: "system"
      });

      this.broadcastToRoom(room.id, {
        type: 'player_joined',
        data: { playerName: data.playerName }
      });

    } catch (error) {
      console.error('Error joining room:', error);
      this.sendError(ws, 'Failed to join room');
    }
  }

  private async handlePlayCard(ws: WebSocket, data: { card: any }) {
    const client = this.clients.get(ws);
    if (!client?.userId || !client?.roomId) {
      this.sendError(ws, 'Not in a room');
      return;
    }

    try {
      const success = await gameService.playCard(client.roomId, client.userId, data.card);
      if (success) {
        await this.sendGameState(client.roomId);
        
        this.broadcastToRoom(client.roomId, {
          type: 'card_played',
          data: { 
            playerName: client.playerName,
            card: data.card 
          }
        });
      } else {
        this.sendError(ws, 'Cannot play card');
      }
    } catch (error) {
      console.error('Error playing card:', error);
      this.sendError(ws, 'Failed to play card');
    }
  }

  private async handleExchangeMoney(ws: WebSocket, data: { amount: number }) {
    const client = this.clients.get(ws);
    if (!client?.userId || !client?.roomId) {
      this.sendError(ws, 'Not in a room');
      return;
    }

    try {
      const bars = await gameService.exchangeMoney(client.userId, client.roomId, data.amount);
      if (bars.length > 0) {
        await this.sendGameState(client.roomId);
        
        this.send(ws, {
          type: 'exchange_success',
          data: { bars, amount: data.amount }
        });
      } else {
        this.sendError(ws, 'Insufficient balance');
      }
    } catch (error) {
      console.error('Error exchanging money:', error);
      this.sendError(ws, 'Failed to exchange money');
    }
  }

  private async handleChatMessage(ws: WebSocket, data: { message: string; messageType?: string }) {
    const client = this.clients.get(ws);
    if (!client?.userId || !client?.roomId || !client?.playerName) {
      this.sendError(ws, 'Not in a room');
      return;
    }

    try {
      const chatMessage = await storage.addChatMessage({
        roomId: client.roomId,
        playerId: client.userId,
        playerName: client.playerName,
        message: data.message,
        messageType: data.messageType || 'chat'
      });

      this.broadcastToRoom(client.roomId, {
        type: 'chat_message',
        data: chatMessage
      });
    } catch (error) {
      console.error('Error sending chat message:', error);
      this.sendError(ws, 'Failed to send message');
    }
  }

  private async handleStartGame(ws: WebSocket) {
    const client = this.clients.get(ws);
    if (!client?.roomId) {
      this.sendError(ws, 'Not in a room');
      return;
    }

    try {
      const success = await gameService.startGame(client.roomId);
      if (success) {
        await this.sendGameState(client.roomId);
        
        this.broadcastToRoom(client.roomId, {
          type: 'game_started',
          data: {}
        });
      } else {
        this.sendError(ws, 'Cannot start game');
      }
    } catch (error) {
      console.error('Error starting game:', error);
      this.sendError(ws, 'Failed to start game');
    }
  }

  private async handleReadyUp(ws: WebSocket) {
    const client = this.clients.get(ws);
    if (!client?.userId || !client?.roomId) {
      this.sendError(ws, 'Not in a room');
      return;
    }

    try {
      const player = await storage.getPlayer(client.roomId, client.userId);
      if (player) {
        await storage.updatePlayer(player.id, { isReady: true });
        await this.sendGameState(client.roomId);
        
        this.broadcastToRoom(client.roomId, {
          type: 'player_ready',
          data: { playerName: client.playerName }
        });
      }
    } catch (error) {
      console.error('Error updating ready status:', error);
      this.sendError(ws, 'Failed to update ready status');
    }
  }

  private async sendGameState(roomId: number) {
    try {
      const room = await storage.getGameRoom(roomId);
      const players = await storage.getPlayersInRoom(roomId);
      const messages = await storage.getChatMessages(roomId, 20);

      if (!room) return;

      const gameState = {
        room,
        players: players.map(p => ({
          ...p,
          // Hide other players' cards
          cards: p.cards
        })),
        messages
      };

      this.broadcastToRoom(roomId, {
        type: 'game_state',
        data: gameState
      });
    } catch (error) {
      console.error('Error sending game state:', error);
    }
  }

  private handleDisconnection(ws: WebSocket) {
    const client = this.clients.get(ws);
    
    if (client?.roomId) {
      // Remove from room clients
      const roomClients = this.roomClients.get(client.roomId);
      if (roomClients) {
        roomClients.delete(ws);
        
        if (roomClients.size === 0) {
          this.roomClients.delete(client.roomId);
        }
      }

      // Remove player from room
      if (client.userId) {
        storage.removePlayerFromRoom(client.roomId, client.userId);
        
        // Notify other players
        this.broadcastToRoom(client.roomId, {
          type: 'player_left',
          data: { playerName: client.playerName }
        });
      }
    }

    this.clients.delete(ws);
    console.log('Client disconnected');
  }

  private broadcastToRoom(roomId: number, message: any) {
    const roomClients = this.roomClients.get(roomId);
    if (roomClients) {
      const messageStr = JSON.stringify(message);
      roomClients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(messageStr);
        }
      });
    }
  }

  private send(ws: WebSocket, message: any) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    }
  }

  private sendError(ws: WebSocket, error: string) {
    this.send(ws, {
      type: 'error',
      data: { message: error }
    });
  }
}
