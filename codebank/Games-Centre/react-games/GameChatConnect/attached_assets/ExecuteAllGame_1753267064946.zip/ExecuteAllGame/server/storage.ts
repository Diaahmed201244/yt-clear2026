import { users, gameRooms, gamePlayers, chatMessages, type User, type InsertUser, type GameRoom, type InsertGameRoom, type GamePlayer, type InsertGamePlayer, type ChatMessage, type InsertChatMessage } from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(id: number, balance: number): Promise<User | undefined>;
  updateUserStats(id: number, wins: number, earnings: number): Promise<User | undefined>;
  
  // Game room operations
  createGameRoom(room: InsertGameRoom): Promise<GameRoom>;
  getGameRoom(id: number): Promise<GameRoom | undefined>;
  getGameRoomByCode(roomCode: string): Promise<GameRoom | undefined>;
  updateGameRoom(id: number, updates: Partial<GameRoom>): Promise<GameRoom | undefined>;
  deleteGameRoom(id: number): Promise<boolean>;
  
  // Game player operations
  addPlayerToRoom(player: InsertGamePlayer): Promise<GamePlayer>;
  getPlayersInRoom(roomId: number): Promise<GamePlayer[]>;
  getPlayer(roomId: number, playerId: number): Promise<GamePlayer | undefined>;
  updatePlayer(id: number, updates: Partial<GamePlayer>): Promise<GamePlayer | undefined>;
  removePlayerFromRoom(roomId: number, playerId: number): Promise<boolean>;
  
  // Chat operations
  addChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getChatMessages(roomId: number, limit?: number): Promise<ChatMessage[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private gameRooms: Map<number, GameRoom>;
  private gamePlayers: Map<number, GamePlayer>;
  private chatMessages: Map<number, ChatMessage>;
  private currentUserId: number;
  private currentRoomId: number;
  private currentPlayerId: number;
  private currentMessageId: number;

  constructor() {
    this.users = new Map();
    this.gameRooms = new Map();
    this.gamePlayers = new Map();
    this.chatMessages = new Map();
    this.currentUserId = 1;
    this.currentRoomId = 1;
    this.currentPlayerId = 1;
    this.currentMessageId = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      balance: 2500, // Starting balance
      wins: 0,
      totalEarnings: 0
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserBalance(id: number, balance: number): Promise<User | undefined> {
    const user = this.users.get(id);
    if (user) {
      const updatedUser = { ...user, balance };
      this.users.set(id, updatedUser);
      return updatedUser;
    }
    return undefined;
  }

  async updateUserStats(id: number, wins: number, earnings: number): Promise<User | undefined> {
    const user = this.users.get(id);
    if (user) {
      const updatedUser = { ...user, wins, totalEarnings: earnings };
      this.users.set(id, updatedUser);
      return updatedUser;
    }
    return undefined;
  }

  // Game room operations
  async createGameRoom(insertRoom: InsertGameRoom): Promise<GameRoom> {
    const id = this.currentRoomId++;
    const room: GameRoom = {
      roomCode: insertRoom.roomCode,
      dealerName: insertRoom.dealerName || "Lady Victoria",
      maxPlayers: insertRoom.maxPlayers || 6,
      maxRounds: insertRoom.maxRounds || 5,
      id,
      currentPlayers: 0,
      gameStatus: "waiting",
      currentRound: 0,
      currentPlayerIndex: 0,
      pot: [],
      deck: this.createShuffledDeck(),
      createdAt: new Date(),
    };
    this.gameRooms.set(id, room);
    return room;
  }

  async getGameRoom(id: number): Promise<GameRoom | undefined> {
    return this.gameRooms.get(id);
  }

  async getGameRoomByCode(roomCode: string): Promise<GameRoom | undefined> {
    return Array.from(this.gameRooms.values()).find(room => room.roomCode === roomCode);
  }

  async updateGameRoom(id: number, updates: Partial<GameRoom>): Promise<GameRoom | undefined> {
    const room = this.gameRooms.get(id);
    if (room) {
      const updatedRoom = { ...room, ...updates };
      this.gameRooms.set(id, updatedRoom);
      return updatedRoom;
    }
    return undefined;
  }

  async deleteGameRoom(id: number): Promise<boolean> {
    return this.gameRooms.delete(id);
  }

  // Game player operations
  async addPlayerToRoom(insertPlayer: InsertGamePlayer): Promise<GamePlayer> {
    const id = this.currentPlayerId++;
    const player: GamePlayer = {
      ...insertPlayer,
      id,
      bars: [],
      cards: [],
      currentCard: null,
      isActive: true,
      isReady: false,
      joinedAt: new Date(),
    };
    this.gamePlayers.set(id, player);

    // Update room player count
    const room = await this.getGameRoom(insertPlayer.roomId);
    if (room) {
      await this.updateGameRoom(room.id, { currentPlayers: room.currentPlayers + 1 });
    }

    return player;
  }

  async getPlayersInRoom(roomId: number): Promise<GamePlayer[]> {
    return Array.from(this.gamePlayers.values()).filter(player => player.roomId === roomId);
  }

  async getPlayer(roomId: number, playerId: number): Promise<GamePlayer | undefined> {
    return Array.from(this.gamePlayers.values()).find(
      player => player.roomId === roomId && player.playerId === playerId
    );
  }

  async updatePlayer(id: number, updates: Partial<GamePlayer>): Promise<GamePlayer | undefined> {
    const player = this.gamePlayers.get(id);
    if (player) {
      const updatedPlayer = { ...player, ...updates };
      this.gamePlayers.set(id, updatedPlayer);
      return updatedPlayer;
    }
    return undefined;
  }

  async removePlayerFromRoom(roomId: number, playerId: number): Promise<boolean> {
    const player = await this.getPlayer(roomId, playerId);
    if (player) {
      this.gamePlayers.delete(player.id);
      
      // Update room player count
      const room = await this.getGameRoom(roomId);
      if (room) {
        await this.updateGameRoom(room.id, { currentPlayers: Math.max(0, room.currentPlayers - 1) });
      }
      
      return true;
    }
    return false;
  }

  // Chat operations
  async addChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = this.currentMessageId++;
    const message: ChatMessage = {
      id,
      message: insertMessage.message,
      roomId: insertMessage.roomId,
      playerId: insertMessage.playerId || null,
      playerName: insertMessage.playerName,
      messageType: insertMessage.messageType || "player",
      timestamp: new Date(),
    };
    this.chatMessages.set(id, message);
    return message;
  }

  async getChatMessages(roomId: number, limit: number = 50): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(message => message.roomId === roomId)
      .sort((a, b) => (b.timestamp?.getTime() ?? 0) - (a.timestamp?.getTime() ?? 0))
      .slice(0, limit)
      .reverse();
  }

  private createShuffledDeck(): any[] {
    const suits = ["hearts", "diamonds", "clubs", "spades"];
    const ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
    const deck = [];

    for (const suit of suits) {
      for (const rank of ranks) {
        let value = parseInt(rank);
        if (rank === "A") value = 14; // Ace high
        if (rank === "J") value = 11;
        if (rank === "Q") value = 12;
        if (rank === "K") value = 13;
        
        deck.push({ suit, rank, value });
      }
    }

    // Shuffle the deck
    for (let i = deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }

    return deck;
  }
}

export const storage = new MemStorage();
