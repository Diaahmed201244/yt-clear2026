import { cn } from "@/lib/utils";
import LadyDealer from "./LadyDealer";
import PlayerPosition from "./PlayerPosition";
import CardDeck from "./CardDeck";
import PotArea from "./PotArea";
import GameControls from "./GameControls";
import type { GameState } from "@shared/schema";
import { soundManager } from "@/lib/soundManager";

interface CasinoTableProps {
  gameState: GameState | null;
  currentUser: any;
  onSendMessage: (message: any) => void;
}

export default function CasinoTable({ gameState, currentUser, onSendMessage }: CasinoTableProps) {
  const handlePlayCard = (card: any) => {
    soundManager.playCardFlip();
    soundManager.playButtonClick();
    onSendMessage({
      type: 'play_card',
      data: { card }
    });
  };

  const isPlayerTurn = gameState?.room && gameState?.players ? 
    gameState.players[gameState.room.currentPlayerIndex]?.playerId === currentUser.id : false;

  // Position players around the table
  const getPlayerPositions = () => {
    if (!gameState?.players) return [];
    
    const positions = [
      { style: "bottom-8 left-1/2 transform -translate-x-1/2" }, // Bottom center
      { style: "bottom-12 right-8" }, // Bottom right
      { style: "right-4 top-1/2 transform -translate-y-1/2" }, // Right middle
      { style: "top-12 right-8" }, // Top right
      { style: "top-12 left-8" }, // Top left
      { style: "left-4 top-1/2 transform -translate-y-1/2" }, // Left middle
    ];

    return gameState.players.map((player, index) => ({
      ...player,
      position: positions[index] || positions[0],
      isCurrentPlayer: player.playerId === currentUser.id,
      isPlayerTurn: isPlayerTurn && player.playerId === currentUser.id,
    }));
  };

  const positionedPlayers = getPlayerPositions();

  return (
    <div className="casino-table velvet-texture rounded-3xl p-8 shadow-2xl border-4 border-casino-gold/30 relative overflow-hidden min-h-[600px]">
      
      {/* Dealer Area */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2">
        <LadyDealer 
          dealerName={gameState?.room.dealerName || "Lady Victoria"}
          status={gameState?.room.gameStatus === "playing" ? "Dealing cards..." : "Waiting for players..."}
        />
      </div>

      {/* Card Deck Area */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <CardDeck 
          remainingCards={gameState?.room.deck ? (gameState.room.deck as any[]).length : 52}
        />
      </div>

      {/* Players */}
      {positionedPlayers.map((player, index) => (
        <div key={player.id} className={cn("absolute", player.position.style)}>
          <PlayerPosition 
            player={player}
            isCurrentUser={player.isCurrentPlayer}
            isPlayerTurn={player.isPlayerTurn}
            onPlayCard={handlePlayCard}
          />
        </div>
      ))}

      {/* Central Pot Area */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 translate-y-8">
        <PotArea 
          pot={gameState?.room.pot as any[] || []}
        />
      </div>

      {/* Game Status */}
      <div className="absolute top-4 right-4">
        <div className="bg-casino-green/80 rounded-lg px-3 py-2 border border-casino-green backdrop-blur-sm">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-casino-gold rounded-full animate-pulse"></div>
            <span className="text-white text-sm font-semibold">
              {gameState?.room.gameStatus === "waiting" ? "Waiting" :
               gameState?.room.gameStatus === "playing" ? `Round ${gameState.room.currentRound} of ${gameState.room.maxRounds}` :
               "Finished"}
            </span>
          </div>
        </div>
      </div>

      {/* Game Controls */}
      {gameState?.room.gameStatus === "playing" && (
        <GameControls 
          isPlayerTurn={isPlayerTurn}
          currentPlayer={gameState.players[gameState.room.currentPlayerIndex]}
          onPlayCard={handlePlayCard}
        />
      )}
    </div>
  );
}
