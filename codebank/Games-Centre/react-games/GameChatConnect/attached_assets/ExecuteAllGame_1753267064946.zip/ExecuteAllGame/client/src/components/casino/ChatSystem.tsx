import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircle, Send } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ChatMessage } from "@shared/schema";

interface ChatSystemProps {
  messages: ChatMessage[];
  onSendMessage: (message: string, messageType?: string) => void;
}

export default function ChatSystem({ messages, onSendMessage }: ChatSystemProps) {
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ 
        behavior: "smooth", 
        block: "nearest",
        inline: "nearest"
      });
    }
  };

  useEffect(() => {
    // Disable auto-scroll completely to prevent page interference
    // Users can manually scroll in chat if needed
  }, [messages]);

  const handleSendMessage = () => {
    if (message.trim()) {
      onSendMessage(message.trim());
      setMessage("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

  const handleEmote = (emote: string) => {
    onSendMessage(emote, "emote");
  };

  const formatTime = (timestamp: Date | string) => {
    const date = typeof timestamp === "string" ? new Date(timestamp) : timestamp;
    return date.toLocaleTimeString("en-US", { 
      hour: "2-digit", 
      minute: "2-digit" 
    });
  };

  return (
    <Card className="bg-black/80 border-casino-gold/30 backdrop-blur-sm overflow-hidden chat-system">
      <CardHeader className="bg-casino-red/80 border-b border-casino-gold/30 py-3">
        <CardTitle className="text-casino-cream font-semibold flex items-center text-base">
          <MessageCircle className="h-4 w-4 mr-2" />
          Table Chat
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-0">
        {/* Messages Area */}
        <div className="h-64 overflow-y-auto p-4 space-y-3">
          {messages.length === 0 ? (
            <div className="text-casino-cream/60 text-center text-sm italic">
              No messages yet. Start the conversation!
            </div>
          ) : (
            messages.map((msg) => (
              <div key={msg.id} className="flex items-start space-x-2">
                {msg.messageType === "system" ? (
                  <div className="text-casino-gold text-sm italic w-full text-center">
                    {msg.message}
                  </div>
                ) : (
                  <>
                    <div className="w-6 h-6 rounded-full bg-casino-gold text-black text-xs flex items-center justify-center flex-shrink-0">
                      {msg.playerName?.charAt(0)?.toUpperCase() || "?"}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <span className="text-casino-gold font-semibold text-sm">
                          {msg.playerName}:
                        </span>
                        <span className="text-casino-cream/60 text-xs">
                          {msg.timestamp && formatTime(msg.timestamp)}
                        </span>
                      </div>
                      <div className={cn(
                        "text-casino-cream text-sm mt-1",
                        msg.messageType === "emote" && "text-2xl"
                      )}>
                        {msg.message}
                      </div>
                    </div>
                  </>
                )}
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>
        
        {/* Input Area */}
        <div className="p-4 border-t border-casino-gold/30">
          <div className="flex space-x-2 mb-3">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type a message..."
              className="flex-1 bg-gray-900 border-casino-gold/30 text-casino-cream text-sm focus:border-casino-gold"
              maxLength={200}
            />
            <Button 
              onClick={handleSendMessage}
              disabled={!message.trim()}
              size="sm"
              className="bg-casino-gold text-black hover:bg-yellow-400"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Quick Emotes */}
          <div className="flex space-x-2">
            {["👍", "😄", "🎉", "🤔", "😮", "💯"].map((emote) => (
              <button
                key={emote}
                onClick={() => handleEmote(emote)}
                className="bg-gray-800 hover:bg-gray-700 text-casino-cream px-2 py-1 rounded text-sm transition-colors"
              >
                {emote}
              </button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
