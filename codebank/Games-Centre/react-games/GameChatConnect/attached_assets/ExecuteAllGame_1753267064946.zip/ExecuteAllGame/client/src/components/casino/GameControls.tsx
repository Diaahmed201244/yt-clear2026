import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Hand, Flag, Clock } from "lucide-react";

interface GameControlsProps {
  isPlayerTurn: boolean;
  currentPlayer: any;
  onPlayCard: (card: any) => void;
}

export default function GameControls({ isPlayerTurn, currentPlayer, onPlayCard }: GameControlsProps) {
  return (
    <Card className="mt-6 bg-black/60 border-casino-gold/30 backdrop-blur-sm">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="flex space-x-4">
            <Button 
              disabled={!isPlayerTurn}
              className="bg-casino-gold text-black hover:bg-yellow-400 font-semibold disabled:opacity-50"
            >
              <Hand className="h-4 w-4 mr-2" />
              Play Card
            </Button>
            <Button 
              variant="outline"
              className="border-casino-red text-casino-red hover:bg-casino-red hover:text-white font-semibold"
            >
              <Flag className="h-4 w-4 mr-2" />
              Fold
            </Button>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-casino-cream">
              <span className="text-sm">Current Turn: </span>
              <span className="font-semibold text-casino-gold">
                {currentPlayer ? currentPlayer.playerName : "Waiting..."}
              </span>
            </div>
            {isPlayerTurn && (
              <div className="bg-casino-red/50 rounded-lg px-3 py-2 flex items-center space-x-2">
                <Clock className="text-casino-gold h-4 w-4" />
                <span className="text-casino-cream font-mono text-sm">Your Turn</span>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}