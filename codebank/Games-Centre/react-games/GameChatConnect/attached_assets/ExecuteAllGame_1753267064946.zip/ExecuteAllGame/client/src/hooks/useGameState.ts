import { useState, useCallback } from "react";
import type { GameState } from "@shared/schema";

interface UseGameStateReturn {
  gameState: GameState | null;
  updateGameState: (newState: Partial<GameState>) => void;
  setGameState: (state: GameState) => void;
  isPlayerTurn: (playerId: number) => boolean;
  getCurrentPlayer: () => any;
}

export function useGameState(): UseGameStateReturn {
  const [gameState, setGameStateInternal] = useState<GameState | null>(null);

  const updateGameState = useCallback((newState: Partial<GameState>) => {
    setGameStateInternal(current => 
      current ? { ...current, ...newState } : null
    );
  }, []);

  const setGameState = useCallback((state: GameState) => {
    setGameStateInternal(state);
  }, []);

  const isPlayerTurn = useCallback((playerId: number): boolean => {
    if (!gameState?.room || !gameState?.players) return false;
    
    const currentPlayer = gameState.players[gameState.room.currentPlayerIndex];
    return currentPlayer?.playerId === playerId;
  }, [gameState]);

  const getCurrentPlayer = useCallback(() => {
    if (!gameState?.room || !gameState?.players) return null;
    
    return gameState.players[gameState.room.currentPlayerIndex];
  }, [gameState]);

  return {
    gameState,
    updateGameState,
    setGameState,
    isPlayerTurn,
    getCurrentPlayer,
  };
}
