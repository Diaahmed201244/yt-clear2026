export interface Player {
  id: number;
  name: string;
  position: number;
  avatar?: string;
  balance: number;
  bars: Bar[];
  cards: Card[];
  currentCard?: Card;
  isActive: boolean;
  isReady: boolean;
  isCurrentPlayer?: boolean;
}

export interface Card {
  suit: "hearts" | "diamonds" | "clubs" | "spades";
  rank: string;
  value: number;
}

export interface Bar {
  type: "gold" | "silver";
  value: number;
}

export interface Room {
  id: number;
  code: string;
  dealerName: string;
  maxPlayers: number;
  currentPlayers: number;
  gameStatus: "waiting" | "playing" | "finished";
  currentRound: number;
  maxRounds: number;
  pot: Bar[];
}

export interface ChatMessage {
  id: number;
  playerName: string;
  message: string;
  messageType: "chat" | "emote" | "system";
  timestamp: Date;
}

export interface GameSettings {
  dealerVoice: boolean;
  soundEffects: boolean;
  backgroundMusic: boolean;
}
