import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Crown, Users, Coins } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Home() {
  const [, setLocation] = useLocation();
  const [roomCode, setRoomCode] = useState("");
  const [username, setUsername] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleCreateRoom = async () => {
    if (!username.trim()) {
      toast({
        title: "Username Required",
        description: "Please enter a username to create a room",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      // Register/login user
      const userResponse = await apiRequest("POST", "/api/auth/register", {
        username: username.trim(),
        password: "temp123", // For demo purposes
      });
      const userData = await userResponse.json();

      // Create room
      const roomResponse = await apiRequest("POST", "/api/rooms/create", {
        dealerName: "Lady Victoria",
        maxPlayers: 6,
        maxRounds: 5,
      });
      const roomData = await roomResponse.json();

      // Store user data
      localStorage.setItem("user", JSON.stringify(userData.user));

      // Navigate to game
      setLocation(`/game/${roomData.room.roomCode}`);
    } catch (error) {
      console.error("Error creating room:", error);
      toast({
        title: "Error",
        description: "Failed to create room. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleJoinRoom = async () => {
    if (!username.trim() || !roomCode.trim()) {
      toast({
        title: "Missing Information",
        description: "Please enter both username and room code",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      // Register/login user
      const userResponse = await apiRequest("POST", "/api/auth/register", {
        username: username.trim(),
        password: "temp123", // For demo purposes
      });
      const userData = await userResponse.json();

      // Check if room exists
      const roomResponse = await apiRequest("GET", `/api/rooms/${roomCode.trim()}`);
      await roomResponse.json(); // Will throw if room doesn't exist

      // Store user data
      localStorage.setItem("user", JSON.stringify(userData.user));

      // Navigate to game
      setLocation(`/game/${roomCode.trim()}`);
    } catch (error) {
      console.error("Error joining room:", error);
      toast({
        title: "Error",
        description: "Room not found or failed to join. Please check the room code.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black">
      {/* Header */}
      <header className="bg-casino-red shadow-2xl border-b-4 border-casino-gold">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-center space-x-4">
            <Crown className="text-casino-gold text-4xl" />
            <h1 className="text-casino-cream font-playfair text-4xl md:text-5xl font-bold">
              Royal Casino
            </h1>
          </div>
          <p className="text-casino-gold text-center mt-2 text-lg">
            Premium Multiplayer Card Gaming Experience
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Create Room */}
          <Card className="bg-black/80 border-casino-gold/30 shadow-2xl">
            <CardHeader className="text-center">
              <CardTitle className="text-casino-gold font-playfair text-2xl flex items-center justify-center space-x-2">
                <Users className="h-6 w-6" />
                <span>Create New Table</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="create-username" className="text-casino-cream">Your Name</Label>
                <Input
                  id="create-username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your username"
                  className="bg-gray-900 border-casino-gold/30 text-casino-cream focus:border-casino-gold"
                />
              </div>

              <div className="bg-casino-green/20 rounded-lg p-4 border border-casino-green/30">
                <h3 className="text-casino-cream font-semibold mb-2">Table Settings</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="text-casino-cream">
                    <span className="text-casino-gold">Dealer:</span> Lady Victoria
                  </div>
                  <div className="text-casino-cream">
                    <span className="text-casino-gold">Max Players:</span> 6
                  </div>
                  <div className="text-casino-cream">
                    <span className="text-casino-gold">Rounds:</span> 5
                  </div>
                  <div className="text-casino-cream">
                    <span className="text-casino-gold">Starting Balance:</span> $2,500
                  </div>
                </div>
              </div>

              <Button 
                onClick={handleCreateRoom}
                disabled={isLoading}
                className="w-full bg-casino-gold text-black hover:bg-yellow-400 font-semibold py-3"
              >
                {isLoading ? "Creating..." : "Create Private Table"}
              </Button>
            </CardContent>
          </Card>

          {/* Join Room */}
          <Card className="bg-black/80 border-casino-gold/30 shadow-2xl">
            <CardHeader className="text-center">
              <CardTitle className="text-casino-gold font-playfair text-2xl flex items-center justify-center space-x-2">
                <Coins className="h-6 w-6" />
                <span>Join Existing Table</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="join-username" className="text-casino-cream">Your Name</Label>
                <Input
                  id="join-username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your username"
                  className="bg-gray-900 border-casino-gold/30 text-casino-cream focus:border-casino-gold"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="room-code" className="text-casino-cream">Room Code</Label>
                <Input
                  id="room-code"
                  value={roomCode}
                  onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                  placeholder="ROYAL-XXXX"
                  className="bg-gray-900 border-casino-gold/30 text-casino-cream focus:border-casino-gold font-mono"
                />
              </div>

              <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-600">
                <h3 className="text-casino-cream font-semibold mb-2 text-sm">How to Get Room Code:</h3>
                <ul className="text-casino-cream text-xs space-y-1">
                  <li>• Ask the table host for the room code</li>
                  <li>• Room codes are in format: ROYAL-XXXX</li>
                  <li>• Join friends' private tables instantly</li>
                </ul>
              </div>

              <Button 
                onClick={handleJoinRoom}
                disabled={isLoading}
                className="w-full bg-casino-green text-white hover:bg-green-700 font-semibold py-3"
              >
                {isLoading ? "Joining..." : "Join Table"}
              </Button>
            </CardContent>
          </Card>
        </div>

        <Separator className="my-12 bg-casino-gold/30" />

        {/* Features */}
        <div className="text-center">
          <h2 className="text-casino-gold font-playfair text-3xl font-bold mb-8">
            Premium Casino Experience
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-black/60 rounded-xl p-6 border border-casino-gold/30">
              <div className="text-casino-gold text-3xl mb-4">♠️</div>
              <h3 className="text-casino-cream font-semibold text-lg mb-2">Real-Time Multiplayer</h3>
              <p className="text-casino-cream/80 text-sm">
                Play with 2-6 players in synchronized real-time gameplay
              </p>
            </div>
            
            <div className="bg-black/60 rounded-xl p-6 border border-casino-gold/30">
              <div className="text-casino-gold text-3xl mb-4">💰</div>
              <h3 className="text-casino-cream font-semibold text-lg mb-2">Gold & Silver Bars</h3>
              <p className="text-casino-cream/80 text-sm">
                Convert your coded money into valuable betting bars
              </p>
            </div>
            
            <div className="bg-black/60 rounded-xl p-6 border border-casino-gold/30">
              <div className="text-casino-gold text-3xl mb-4">👩‍💼</div>
              <h3 className="text-casino-cream font-semibold text-lg mb-2">Professional Dealer</h3>
              <p className="text-casino-cream/80 text-sm">
                Lady Victoria guides your game with voice announcements
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
