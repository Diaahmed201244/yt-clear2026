import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useGameState } from "@/hooks/useGameState";
import { useToast } from "@/hooks/use-toast";
import CasinoTable from "@/components/casino/CasinoTable";
import MoneyExchange from "@/components/casino/MoneyExchange";
import ChatSystem from "@/components/casino/ChatSystem";
import { Button } from "@/components/ui/button";
import { Crown, Share2, Users, Key } from "lucide-react";
import { soundManager } from "@/lib/soundManager";

export default function Game() {
  const [, params] = useRoute("/game/:roomCode");
  const roomCode = params?.roomCode;
  const [user, setUser] = useState<any>(null);
  const { gameState, setGameState } = useGameState();
  const { toast } = useToast();

  // Prevent any automatic scrolling
  useEffect(() => {
    // Disable scroll restoration completely
    if ('scrollRestoration' in window.history) {
      window.history.scrollRestoration = 'manual';
    }
    
    return () => {
      if ('scrollRestoration' in window.history) {
        window.history.scrollRestoration = 'auto';
      }
    };
  }, []);

  const { isConnected, send } = useWebSocket((message) => {
    switch (message.type) {
      case 'game_state':
        setGameState(message.data);
        break;
      
      case 'error':
        toast({
          title: "Error",
          description: message.data.message,
          variant: "destructive",
        });
        break;
      
      case 'player_joined':
        toast({
          title: "Player Joined",
          description: `${message.data.playerName} joined the table`,
        });
        break;
      
      case 'game_started':
        soundManager.playDealerVoice("Welcome to the table! Cards are now being dealt. Good luck everyone!");
        toast({
          title: "Game Started",
          description: "Let the cards be dealt!",
        });
        break;
      
      case 'card_played':
        soundManager.playCardFlip();
        toast({
          title: "Card Played",
          description: `${message.data.playerName} played ${message.data.card.rank}${message.data.card.suit}`,
        });
        break;
    }
  });

  useEffect(() => {
    // Load user from localStorage
    const userData = localStorage.getItem("user");
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  useEffect(() => {
    // Join room when connected
    if (isConnected && user && roomCode) {
      send({
        type: 'join_room',
        data: {
          roomCode,
          playerId: user.id,
          playerName: user.username,
        }
      });
    }
  }, [isConnected, user, roomCode, send]);

  const handleInvitePlayer = () => {
    if (roomCode) {
      soundManager.playButtonClick();
      const inviteUrl = `${window.location.origin}/game/${roomCode}`;
      navigator.clipboard.writeText(inviteUrl);
      toast({
        title: "Invite Link Copied",
        description: "Share the link with friends to invite them to your table",
      });
    }
  };

  const handleStartGame = () => {
    soundManager.playButtonClick();
    soundManager.playDealerVoice("Starting the game now. Please wait while I deal the cards.");
    send({ type: 'start_game', data: {} });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black flex items-center justify-center">
        <div className="text-casino-cream text-center">
          <Crown className="text-casino-gold text-6xl mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Loading Game...</h2>
          <p>Please wait while we prepare your table</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black font-inter">
      {/* Header */}
      <header className="bg-casino-red shadow-2xl border-b-4 border-casino-gold">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Crown className="text-casino-gold text-3xl" />
              <h1 className="text-casino-cream font-playfair text-2xl md:text-3xl font-bold">
                Royal Casino
              </h1>
            </div>
            
            <div className="flex items-center space-x-6">
              {/* Player Balance */}
              <div className="bg-black/30 rounded-lg px-4 py-2 border border-casino-gold/30">
                <div className="flex items-center space-x-2">
                  <Users className="text-casino-gold h-4 w-4" />
                  <span className="text-casino-cream font-semibold">
                    ${user.balance.toLocaleString()}
                  </span>
                </div>
              </div>
              
              {/* Room Code Display */}
              <div className="bg-casino-green/20 rounded-lg px-3 py-2 border border-casino-green">
                <div className="flex items-center space-x-2">
                  <Key className="text-casino-green h-4 w-4" />
                  <span className="text-casino-cream text-sm font-mono">
                    {roomCode}
                  </span>
                </div>
              </div>
              
              <Button 
                onClick={handleInvitePlayer}
                className="bg-casino-gold text-black hover:bg-yellow-400 font-semibold"
              >
                <Share2 className="h-4 w-4 mr-2" />
                Invite
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* Main Game Area */}
          <div className="lg:col-span-3">
            <CasinoTable 
              gameState={gameState}
              currentUser={user}
              onSendMessage={send}
            />
            
            {/* Game Controls */}
            <div className="mt-6 bg-black/60 rounded-xl p-6 border border-casino-gold/30 backdrop-blur-sm">
              <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
                <div className="flex space-x-4">
                  {gameState?.room.gameStatus === "waiting" && (
                    <Button 
                      onClick={handleStartGame}
                      className="bg-casino-gold text-black hover:bg-yellow-400 font-semibold"
                    >
                      Start Game
                    </Button>
                  )}
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-casino-cream">
                    <span className="text-sm">Status: </span>
                    <span className="font-semibold text-casino-gold">
                      {gameState?.room.gameStatus === "waiting" ? "Waiting for players" : 
                       gameState?.room.gameStatus === "playing" ? `Round ${gameState.room.currentRound}` : 
                       "Game finished"}
                    </span>
                  </div>
                  {gameState?.room.gameStatus === "playing" && (
                    <div className="bg-casino-red/50 rounded-lg px-3 py-2">
                      <span className="text-casino-cream font-mono">
                        Players: {gameState.players.length}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <MoneyExchange 
              user={user}
              onExchange={(amount) => send({ 
                type: 'exchange_money', 
                data: { amount } 
              })}
            />
            
            <ChatSystem 
              messages={gameState?.messages || []}
              onSendMessage={(message, messageType) => send({
                type: 'chat_message',
                data: { message, messageType }
              })}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
